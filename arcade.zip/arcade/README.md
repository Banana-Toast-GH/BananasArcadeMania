# 🍌 Banana's Arcade Mania

A retro 3D arcade experience. Host on GitHub Pages and play 35 classics.

## 📁 Structure
```
index.html        ← Main arcade hub (open this)
games/
  pong.html
  breakout.html
  spaceinvaders.html
  asteroids.html
  pacman.html
  tetris.html
  ... (35 total)
```

## 🚀 GitHub Pages Setup
1. Push this folder to a GitHub repo
2. Go to Settings → Pages → Deploy from branch → `main` / `root`
3. Visit `https://yourusername.github.io/reponame/`

## 🎮 Controls
| Key | Action |
|-----|--------|
| `Q` / `E` or `←` `→` | Cycle machines |
| `ENTER` | Insert token & play |
| `TAB` | Open game directory |
| `ESC` (hold 2.5s) | Exit game |

## 🪙 Token System
- 10 tokens per day, refills after 24 hours
- Watch a 1.5s ad for +1 token (90s cooldown)
- Scores saved to localStorage per browser

## 🎯 Games Included
4 fully playable: Pong, Breakout, Space Invaders, Asteroids, Pac-Man, Tetris  
29 animated placeholders — ready for you to implement!

## ✏️ Adding a Game
Each game file is a standalone HTML page. Post your score back to the arcade:
```js
window.parent.postMessage({ type: 'SCORE', id: 'yourgameid', score: 9999 }, '*');
```
